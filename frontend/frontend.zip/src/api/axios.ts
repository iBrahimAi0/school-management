// src/api/axios.ts
import axios from "axios";

export const axiosClient = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000",
  headers: {
    "X-Requested-With": "XMLHttpRequest",
    Accept: "application/json",
    "Content-Type": "application/json",
  },
  withCredentials: true,
  withXSRFToken: true,
});

axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && typeof window !== "undefined") {
      document.cookie =
        "is_logged_in=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;";
      if (window.location.pathname.startsWith("/student")) {
        window.location.href = "/login";
      }
    }
    return Promise.reject(error);
  },
);
