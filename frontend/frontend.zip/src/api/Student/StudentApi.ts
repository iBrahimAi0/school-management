import { valuesType } from "@/types/ValuesType";
import { axiosClient } from "../axios";

export const StudentApi = {
  getCsrf: async () => {
    await axiosClient.get("/sanctum/csrf-cookie");
  },
  login: async ({ email, password }: valuesType) => {
    try {
      return await axiosClient.post("/api/login", {
        email,
        password,
      });
    } catch (error: any) {
      console.log("LOGIN ERROR:", error.response?.data);
      console.log("STATUS:", error.response?.status);
      throw error;
    }
  },
  logout: async () => {
    return await axiosClient.post("/api/logout");
  },
  getMe: async () => {
    return await axiosClient.get("/api/me");
  },
  getUser: async () => {
    return await axiosClient.get("/api/user");
  },
};
