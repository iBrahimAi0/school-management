// src/app/student/dashboard/page.tsx
"use client";

import { useUserContext } from "@/context/UserProvider";
import { SpinnerSize } from "@/components/Spiner";
import {
  SidebarProvider,
  SidebarInset,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/add-sidebar";
import { Separator } from "@/components/ui/separator";

export default function AdminDashboard() {
  const { user, loader } = useUserContext();

  if (loader) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <SpinnerSize />
      </div>
    );
  }

  return (
    <SidebarProvider className="min-h-[calc(100vh-4rem)] w-full">
      {/* 1. Collapsible Sidebar with smooth width transition (16rem -> 3rem) */}
      <AppSidebar />

      {/* 2. Main content that automatically expands to the left when sidebar collapses */}
      <SidebarInset className="flex flex-col flex-1 w-full overflow-x-hidden">
        <header className="flex h-12 shrink-0 items-center gap-2 border-b border-border px-4 bg-background/95 backdrop-blur">
          <SidebarTrigger className="-ml-1" />
          <Separator orientation="vertical" className="mr-2 h-4" />
          <span className="text-sm font-medium text-muted-foreground">
            Admin Overview
          </span>
        </header>

        <div className="flex-1 p-6 space-y-6 overflow-y-auto">
          <div>
            <h2 className="text-2xl font-bold tracking-tight">
              Hi, {user?.name ?? "Admin"} 👋
            </h2>
            <p className="text-muted-foreground text-sm">Welcome back Admin.</p>
          </div>
        </div>
      </SidebarInset>
    </SidebarProvider>
  );
}
