import { StudentLogin } from "@/components/StudentLogin";

export default function Login() {
  return (
    <div className="flex flex-1 min-h-[calc(100vh-4rem)] items-center justify-center p-4">
      <StudentLogin />
    </div>
  );
}
