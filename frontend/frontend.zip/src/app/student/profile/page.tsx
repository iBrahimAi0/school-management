"use client";
import { useUserContext } from "@/context/UserProvider";

export default function Profile() {
  return (
    <div>
      <h1>Student Profile</h1>
    </div>
  );
}
