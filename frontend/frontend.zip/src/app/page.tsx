export default function Home() {
  return <div>Hi from homePage</div>;
}
