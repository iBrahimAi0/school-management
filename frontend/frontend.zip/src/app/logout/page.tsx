"use client";
import { SpinnerSize } from "@/components/Spiner";
import { useUserContext } from "@/context/UserProvider";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function Logout() {
  const router = useRouter();
  const { logout } = useUserContext();
  useEffect(() => {
    const logoutCallback = async () => {
      try {
        await logout();
      } catch {
        router.replace("/login");
      }
    };

    void logoutCallback();
  }, [logout, router]);
  return (
    <div className="flex h-screen items-center justify-center">
      <SpinnerSize />
    </div>
  );
}
