import {
  CreditCardIcon,
  LogOutIcon,
  SettingsIcon,
  UserIcon,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import Link from "next/link";
import { DashboardIcon } from "./icons/akar-icons-dashboard";

export function DropdownMenuIcons({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <DropdownMenu>
      <DropdownMenuContent>
        <DropdownMenuTrigger asChild>
          <Button variant="outline">{children}</Button>
          <Button variant="outline" className="flex items-center gap-2">
            {children}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem>
            <DashboardIcon />
            <Link href="/student/dashboard">Dashboard</Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem asChild>
            <Link
              href="/student/dashboard"
              className="flex items-center gap-2 cursor-pointer w-full"
            >
              <DashboardIcon />
              <span>Dashboard</span>
            </Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
        <DropdownMenuItem>
          <UserIcon />
          <Link href="/student/profile">Profile</Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild>
          <Link
            href="/student/profile"
            className="flex items-center gap-2 cursor-pointer w-full"
          >
            <UserIcon className="h-4 w-4" />
            <span>Profile</span>
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <CreditCardIcon />
          Billing
        </DropdownMenuItem>
        <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
          <CreditCardIcon className="h-4 w-4" />
          <span>Billing</span>
        </DropdownMenuItem>
        <DropdownMenuItem>
          <SettingsIcon />
          Settings
        </DropdownMenuItem>
        <DropdownMenuItem className="flex items-center gap-2 cursor-pointer">
          <SettingsIcon className="h-4 w-4" />
          <span>Settings</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem variant="destructive">
          <LogOutIcon />
          <Link href="/logout">Log out</Link>
        </DropdownMenuItem>
        <DropdownMenuItem variant="destructive" asChild>
          <Link
            href="/logout"
            className="flex items-center gap-2 cursor-pointer w-full text-destructive"
          >
            <LogOutIcon className="h-4 w-4" />
            <span>Log out</span>
          </Link>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
