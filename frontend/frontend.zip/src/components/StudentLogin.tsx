"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { Controller, useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import {
    Card,
    CardContent,
    CardFooter,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import {
    Field,
    FieldError,
    FieldGroup,
    FieldLabel,
} from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { loginSchema } from "@/schema/loginSchema";
import * as z from "zod";
import { useRouter } from "next/navigation";
import { Loader } from "lucide-react";
import { useUserContext } from "@/context/UserProvider";
import { isAxiosError } from "axios";

type LoginErrorResponse = {
    errors?: {
        email?: string[];
    };
};
export function StudentLogin() {
    const { login } = useUserContext();
    const router = useRouter();
    const form = useForm<z.infer<typeof loginSchema>>({
        resolver: zodResolver(loginSchema),
        defaultValues: {
            email: "",
            password: "",
        },
    });
    const { isSubmitting } = form.formState;
    const onSubmit = async (values: z.infer<typeof loginSchema>) => {
        try {
            await login(values);
            router.push("/student/dashboard");
        } catch (error: unknown) {
            const response = isAxiosError<LoginErrorResponse>(error)
                ? error.response?.data
                : undefined;

            form.setError("email", {
                message:
                    response?.errors?.email?.[0] ??
                    "Unable to log in. Please check your details and try again.",
            });
        }
    };

    return (
        <Card className="w-full sm:max-w-md">
            <CardHeader>
                <CardTitle>Student Login</CardTitle>
            </CardHeader>
            <CardContent>
                <form
                    id="form-rhf-input"
                    onSubmit={form.handleSubmit(onSubmit)}
                >
                    <FieldGroup>
                        <Controller
                            name="email"
                            control={form.control}
                            render={({ field, fieldState }) => (
                                <Field data-invalid={fieldState.invalid}>
                                    <FieldLabel htmlFor="form-rhf-input-email">
                                        Email
                                    </FieldLabel>
                                    <Input
                                        {...field}
                                        id="form-rhf-input-email"
                                        aria-invalid={fieldState.invalid}
                                        placeholder="test@example.co"
                                        autoComplete="email"
                                    />
                                    {fieldState.invalid && (
                                        <FieldError
                                            errors={[fieldState.error]}
                                        />
                                    )}
                                </Field>
                            )}
                        />
                    </FieldGroup>
                    <FieldGroup>
                        <Controller
                            name="password"
                            control={form.control}
                            render={({ field, fieldState }) => (
                                <Field
                                    data-invalid={fieldState.invalid}
                                    className="py-3"
                                >
                                    <FieldLabel htmlFor="form-rhf-input-password">
                                        Password
                                    </FieldLabel>
                                    <Input
                                        {...field}
                                        type="password"
                                        id="form-rhf-input-password"
                                        aria-invalid={fieldState.invalid}
                                        placeholder="Password"
                                        autoComplete="current-password"
                                    />

                                    {fieldState.invalid && (
                                        <FieldError
                                            errors={[fieldState.error]}
                                        />
                                    )}
                                </Field>
                            )}
                        />
                    </FieldGroup>
                </form>
            </CardContent>
            <CardFooter>
                <Field orientation="horizontal">
                    <Button
                        disabled={isSubmitting}
                        type="submit"
                        form="form-rhf-input"
                    >
                        {isSubmitting && <Loader className=" animate-spin" />}{" "}
                        Login
                    </Button>
                </Field>
            </CardFooter>
        </Card>
    );
}
