"use client";
import { StudentApi } from "@/api/Student/StudentApi";
import { valuesType } from "@/types/ValuesType";
import { useRouter } from "next/navigation";
import { createContext, useContext, useEffect, useState } from "react";

interface User {
  name?: string;
  firstname?: string;
  lastname?: string;
  email: string;
}

type Role = "admin" | "teacher" | "student" | null;

interface UserStateContextType {
  user: User | null;
  login: (values: valuesType) => Promise<void>;
  logout: () => Promise<void>;
  role: Role;
  loader: boolean;
}

const UserContext = createContext<UserStateContextType | null>(null);

export const UserProvider = ({
  children,
}: Readonly<{ children: React.ReactNode }>) => {
  const [user, setUser] = useState<User | null>(null);
  const [loader, setLoader] = useState(true);
  const [role, setRole] = useState<Role>(null);
  const router = useRouter();

  // Rehydrate state on page refresh
  useEffect(() => {
    const hasRoleCookie = document.cookie
      .split("; ")
      .some((item) => item.startsWith("user_role="));

    if (!hasRoleCookie) {
      setLoader(false);
      return;
    }

    const fetchSession = async () => {
      try {
        const { data } = await StudentApi.getUser(); // or StudentApi.getMe()
        setUser(data.user);
        setRole(data.role);
      } catch (error: any) {
        document.cookie =
          "user_role=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;";
        setUser(null);
        setRole(null);
      } finally {
        setLoader(false);
      }
    };

    fetchSession();
  }, []);

  const login = async ({ email, password }: valuesType) => {
    setLoader(true);
    try {
      // 1. Set CSRF cookie
      await StudentApi.getCsrf();

      // 2. Submit credentials (Login returns role and user)
      const res = await StudentApi.login({ email, password });
      const authData = res.data;

      setUser(authData.user);
      setRole(authData.role);

      // 3. Store routing hint cookie for Next.js middleware
      document.cookie = `user_role=${authData.role}; path=/; max-age=604800; SameSite=Lax`;

      // 4. Redirect using authData.role (NOT state variable 'role')
      router.push(`/${authData.role}/dashboard`);
    } catch (error: unknown) {
      console.error("Login failed:", error);
      throw error;
    } finally {
      setLoader(false);
    }
  };

  const logout = async (): Promise<void> => {
    setLoader(true);
    try {
      await StudentApi.logout();
    } catch (error) {
      console.error("Logout error:", error);
    } finally {
      document.cookie =
        "user_role=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT;";
      setUser(null);
      setRole(null);
      setLoader(false);
      router.push("/login");
    }
  };

  return (
    <UserContext.Provider value={{ user, login, role, logout, loader }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUserContext = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUserContext must be used inside UserProvider");
  }
  return context;
};
